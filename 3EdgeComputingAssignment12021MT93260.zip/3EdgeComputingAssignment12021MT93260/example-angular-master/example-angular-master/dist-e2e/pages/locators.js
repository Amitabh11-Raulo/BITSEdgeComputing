"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
;
var Locator = (function () {
    function Locator(args) {
        if (args === void 0) { args = []; }
        this.args = args;
    }
    Locator.prototype.className = function (value) {
        return this.add('class name', value);
    };
    Locator.prototype.css = function (value) {
        return this.add('css selector', value);
    };
    Locator.prototype.id = function (value) {
        return this.add('id', value);
    };
    Locator.prototype.name = function (value) {
        return this.add('name', value);
    };
    Locator.prototype.linkText = function (value) {
        return this.add('link text', value);
    };
    Locator.prototype.partialLinkText = function (value) {
        return this.add('partial link text', value);
    };
    Locator.prototype.tagName = function (value) {
        return this.add('tag name', value);
    };
    Locator.prototype.xpath = function (value) {
        return this.add('xpath', value);
    };
    Locator.prototype.add = function (using, value) {
        return new Locator(this.args.concat([{ using: using, value: value }]));
    };
    return Locator;
}());
exports.Locator = Locator;
exports.By = {
    className: function (value) {
        return new Locator().className(value);
    },
    css: function (value) {
        return new Locator().css(value);
    },
    id: function (value) {
        return new Locator().id(value);
    },
    name: function (value) {
        return new Locator().name(value);
    },
    linkText: function (value) {
        return new Locator().linkText(value);
    },
    partialLinkText: function (value) {
        return new Locator().partialLinkText(value);
    },
    tagName: function (value) {
        return new Locator().tagName(value);
    },
    xpath: function (value) {
        return new Locator().xpath(value);
    }
};
function find(command, locator) {
    return tslib_1.__awaiter(this, void 0, void 0, function () {
        var _this = this;
        return tslib_1.__generator(this, function (_a) {
            return [2, locator.args.reduce(function (previous, _a) {
                    var using = _a.using, value = _a.value;
                    return tslib_1.__awaiter(_this, void 0, void 0, function () {
                        var element;
                        return tslib_1.__generator(this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4, previous];
                                case 1:
                                    element = ((_a.sent()) || command);
                                    return [2, element.find(using, value)];
                            }
                        });
                    });
                }, Promise.resolve(null))];
        });
    });
}
exports.find = find;
function findDisplayed(command, locator) {
    return tslib_1.__awaiter(this, void 0, void 0, function () {
        var _this = this;
        return tslib_1.__generator(this, function (_a) {
            return [2, locator.args.reduce(function (previous, _a) {
                    var using = _a.using, value = _a.value;
                    return tslib_1.__awaiter(_this, void 0, void 0, function () {
                        var element;
                        return tslib_1.__generator(this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4, previous];
                                case 1:
                                    element = ((_a.sent()) || command);
                                    return [2, element.findDisplayed(using, value)];
                            }
                        });
                    });
                }, Promise.resolve(null))];
        });
    });
}
exports.findDisplayed = findDisplayed;
//# sourceMappingURL=locators.js.map