"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var Page_1 = require("./Page");
var locators_1 = require("./locators");
function load() {
    return tslib_1.__awaiter(this, void 0, void 0, function () {
        var remote;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    remote = this.parent;
                    return [4, remote.setFindTimeout(5000)];
                case 1:
                    _a.sent();
                    return [4, remote.get('dist/index.html')];
                case 2:
                    _a.sent();
                    return [4, remote.findDisplayedByCssSelector('my-app[ng-version]')];
                case 3:
                    _a.sent();
                    return [2];
            }
        });
    });
}
exports.load = load;
var Home = (function (_super) {
    tslib_1.__extends(Home, _super);
    function Home() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._app = locators_1.By.css('my-app[ng-version]');
        _this._nav = _this._app.xpath('./nav');
        _this._dashboard = _this._app.css('app-dashboard');
        _this._heroes = _this._app.css('app-heroes');
        _this._about = _this._app.css('app-about');
        return _this;
    }
    Home.prototype.load = function () {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var remote;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4, _super.prototype.load.call(this)];
                    case 1:
                        _a.sent();
                        remote = this.remote;
                        return [4, remote.get('dist/index.html')];
                    case 2:
                        _a.sent();
                        return [4, this.waitForApp()];
                    case 3:
                        _a.sent();
                        return [2];
                }
            });
        });
    };
    Home.prototype.getApp = function () {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                return [2, this._find(this._app)];
            });
        });
    };
    Home.prototype.getNav = function () {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                return [2, this._find(this._nav)];
            });
        });
    };
    Home.prototype.getDashboard = function () {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                return [2, this._find(this._dashboard)];
            });
        });
    };
    Home.prototype.getHeroes = function () {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                return [2, this._find(this._heroes)];
            });
        });
    };
    Home.prototype.getAbout = function () {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                return [2, this._find(this._about)];
            });
        });
    };
    Home.prototype.clickHeroesNav = function () {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4, this._clickNav('/heroes')];
                    case 1:
                        _a.sent();
                        return [2];
                }
            });
        });
    };
    Home.prototype.clickAboutNav = function () {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4, this._clickNav('/about')];
                    case 1:
                        _a.sent();
                        return [2];
                }
            });
        });
    };
    Home.prototype.waitForApp = function () {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                return [2, this._findDisplayed(this._app)];
            });
        });
    };
    Home.prototype.waitForDashboard = function () {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                return [2, this._findDisplayed(this._dashboard)];
            });
        });
    };
    Home.prototype.waitForHeroes = function () {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                return [2, this._findDisplayed(this._heroes)];
            });
        });
    };
    Home.prototype.waitForAbout = function () {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                return [2, this._findDisplayed(this._about)];
            });
        });
    };
    Home.prototype._clickNav = function (route) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var nav, link;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4, this.getNav()];
                    case 1:
                        nav = _a.sent();
                        return [4, this._find(locators_1.By.xpath("./a[@routerlink=\"" + route + "\"]"), nav)];
                    case 2:
                        link = _a.sent();
                        return [4, link.click()];
                    case 3:
                        _a.sent();
                        return [2];
                }
            });
        });
    };
    return Home;
}(Page_1.default));
exports.default = Home;
//# sourceMappingURL=Home.js.map