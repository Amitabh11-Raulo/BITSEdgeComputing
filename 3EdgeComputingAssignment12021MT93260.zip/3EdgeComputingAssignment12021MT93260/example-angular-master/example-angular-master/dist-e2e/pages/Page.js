"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var locators_1 = require("./locators");
var Page = (function () {
    function Page(remote) {
        this.remote = remote;
    }
    Page.prototype.load = function () {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4, this.remote.setFindTimeout(5000)];
                    case 1:
                        _a.sent();
                        return [2];
                }
            });
        });
    };
    Page.prototype.getCurrentUrl = function () {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                return [2, this.remote.getCurrentUrl()];
            });
        });
    };
    Page.prototype._find = function (selector, command) {
        if (command === void 0) { command = this.remote; }
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                if (typeof selector === 'string') {
                    return [2, command.findByCssSelector(selector)];
                }
                return [2, locators_1.find(command, selector)];
            });
        });
    };
    Page.prototype._findDisplayed = function (selector, command) {
        if (command === void 0) { command = this.remote; }
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                if (typeof selector === 'string') {
                    return [2, command.findDisplayedByCssSelector(selector)];
                }
                return [2, locators_1.findDisplayed(command, selector)];
            });
        });
    };
    return Page;
}());
exports.default = Page;
//# sourceMappingURL=Page.js.map