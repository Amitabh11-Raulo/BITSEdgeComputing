"use strict";
var _this = this;
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var _a = intern.getPlugin('interface.bdd'), describe = _a.describe, it = _a.it, before = _a.before;
var expect = intern.getPlugin('chai').expect;
var Home_1 = require("./pages/Home");
describe('E2E Tests', function () {
    var page;
    before(function (_a) {
        var remote = _a.remote;
        return tslib_1.__awaiter(_this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        page = new Home_1.default(remote);
                        return [4, page.load()];
                    case 1:
                        _a.sent();
                        return [2];
                }
            });
        });
    });
    it('should begin at /dashboard', function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var _a, _b;
        return tslib_1.__generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    _a = expect;
                    return [4, page.getCurrentUrl()];
                case 1:
                    _a.apply(void 0, [_c.sent()]).to.match(/\/dashboard$/);
                    _b = expect;
                    return [4, page.getDashboard()];
                case 2:
                    _b.apply(void 0, [_c.sent()]).to.exist;
                    return [2];
            }
        });
    }); });
    it('should navigate to /heroes when clicking Heroes', function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var _a;
        return tslib_1.__generator(this, function (_b) {
            switch (_b.label) {
                case 0: return [4, page.clickHeroesNav()];
                case 1:
                    _b.sent();
                    return [4, page.waitForHeroes()];
                case 2:
                    _b.sent();
                    _a = expect;
                    return [4, page.getCurrentUrl()];
                case 3:
                    _a.apply(void 0, [_b.sent()]).to.match(/\/heroes$/);
                    return [2];
            }
        });
    }); });
    it('should navigate to /about when clicking About', function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var _a;
        return tslib_1.__generator(this, function (_b) {
            switch (_b.label) {
                case 0: return [4, page.clickAboutNav()];
                case 1:
                    _b.sent();
                    return [4, page.waitForAbout()];
                case 2:
                    _b.sent();
                    _a = expect;
                    return [4, page.getCurrentUrl()];
                case 3:
                    _a.apply(void 0, [_b.sent()]).to.match(/\/about$/);
                    return [2];
            }
        });
    }); });
});
//# sourceMappingURL=app.e2e-spec.js.map